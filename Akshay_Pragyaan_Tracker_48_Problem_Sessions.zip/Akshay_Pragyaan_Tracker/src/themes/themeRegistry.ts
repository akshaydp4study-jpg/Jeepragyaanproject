import { nervTerminal } from './nerv-terminal';
import { urbanWild } from './urban-wild';
import { expeditionEditorial } from './expedition-editorial';
import { ultralightHex } from './ultralight-hex';
import { wanderlustJapan } from './wanderlust-japan';
import { duotoneFolio } from './duotone-folio';

export const themeRegistry: Record<string, any> = {
  'nerv-terminal': nervTerminal,
  'urban-wild': urbanWild,
  'expedition-editorial': expeditionEditorial,
  'ultralight-hex': ultralightHex,
  'wanderlust-japan': wanderlustJapan,
  'duotone-folio': duotoneFolio,
};
