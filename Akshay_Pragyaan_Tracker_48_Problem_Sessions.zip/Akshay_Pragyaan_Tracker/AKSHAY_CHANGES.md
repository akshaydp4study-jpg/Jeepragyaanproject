# Akshay Pragyaan Tracker — Changes

The original website design, routes, themes, dashboard, tests area, settings, and offline IndexedDB behavior are preserved.

Syllabus replacement:

- Physics: 97 corrected Pragyaan lectures
- Chemistry: 98 corrected Pragyaan lectures across Physical, Inorganic, and Organic sections
- Mathematics: 100 corrected Pragyaan tracker entries
- Total: 295 lectures
- Real lecture codes are displayed, including bridge lectures such as `L-0`
- Organic Chemistry now renders normally instead of the original empty placeholder
- A fresh IndexedDB name prevents the old website's seed data from appearing

Validation completed:

- `npm run lint`
- `npm run test -- --run` — 8 tests passed
- `npm run build`

To run locally:

```bash
npm ci
npm run dev
```

The production-ready static files are also included in `dist/`.


Theory planning upgrade:

- Added a dashboard panel for planned theoretical lecture coverage versus actual lecture completion
- Planned coverage is calculated linearly between the configurable theory start date and Phase 1 deadline
- Shows lectures expected by today, lectures actually completed, and the ahead/behind lecture gap
- Shows actual lectures per day and the pace required from now to meet the deadline
- Projects the theoretical completion date using the achieved pace
- Default theory plan start date is July 4, 2026 and can be changed in Settings
- Existing IndexedDB progress and older JSON backups are upgraded without overwriting saved preferences

Latest validation:

- `npm run lint`
- `npm run test -- --run` — 12 tests passed
- `npm run build`

## 48-session problem-solving phase
- Added a dedicated checklist for 48 post-syllabus problem-solving sessions.
- Added independent session progress, percentage, mark-all, and reset controls.
- Added a dashboard summary and navigation entry across every theme.
- Kept theoretical lecture completion separate from problem-solving completion.
- Added migration-safe IndexedDB storage and backward-compatible backup import.
